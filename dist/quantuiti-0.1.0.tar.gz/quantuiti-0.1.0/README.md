# quantuiti

quantuiti is a platform designed to make automated trading easier

To get started install qantuiti python package
```Shell
pip3 install quantuiti
```
