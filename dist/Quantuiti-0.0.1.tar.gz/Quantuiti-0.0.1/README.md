# CompuTrade

Quantuiti is a platform designed to make automated trading easier
