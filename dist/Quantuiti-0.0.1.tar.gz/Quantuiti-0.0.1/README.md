# Quantuiti

Quantuiti is a platform designed to make automated trading easier

To get started install Quantuiti python package
'''Shell
pip3 install Quantuiti
'''